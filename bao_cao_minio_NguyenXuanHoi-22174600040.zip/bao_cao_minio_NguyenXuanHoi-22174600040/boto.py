import boto3 
from botocore.client import Config 
 
s3 = boto3.client('s3', 
    endpoint_url='http://localhost:9000', 
    aws_access_key_id='xuanhoi262', 
    aws_secret_access_key='12345678', 
    config=Config(signature_version='s3v4'), 
    region_name='us-east-1') 
 
s3.download_file('xuanhoi262', 'iris.csv', 'sensor_data.csv') 
print("Download thành công!")